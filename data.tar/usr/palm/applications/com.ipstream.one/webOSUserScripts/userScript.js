function addDev() {
    webOS.service.request("luna://com.webos.service.eim", {
        method: "addDevice",
        parameters: {
            appId: "com.ipstream.one",
            pigImage: "/snapshot.png",
            type: "MVPD_IP",
            showPopup: !0,
            label: "IPStream.one",
            description: "IPStream.one/IPStr.im IPTV player for WebOS"
        },
        onSuccess: function (e) {
            logmsg("Success: " + JSON.stringify(e));
        },
        onFailure: function (e) {
            logmsg("Failure: " + JSON.stringify(e));
        }
    });
}

function notify() {
    webOS.service.request("luna://com.webos.notification", {
        method: "createToast",
        parameters: {
            sourceId: "com.ipstream.one",
            message: "Вход IPStream.one удален"
        },
        onSuccess: function (e) {
            console.log("[Notification fired] ");
        },
        onFailure: function (e) {
            console.log("[Notification failed] ");
        }
    });
}

function deleteDev() {
    webOS.service.request("luna://com.webos.service.eim", {
        method: "deleteDevice",
        parameters: {
            appId: "com.ipstream.one"
        },
        onSuccess: function (e) {
            notify();
        },
        onFailure: function (e) {
            logmsg("Failure: " + JSON.stringify(e));
        }
    });
}

function runOnKeys(e, ...o) {
    let t = new Set();
    document.addEventListener("keydown", function (n) {
        t.add(n.keyCode);
        for (let e of o) if (!t.has(e)) return;
        t.clear(), e();
    });
    document.addEventListener("keyup", function (e) {
        t.delete(e.keyCode);
    });
}

runOnKeys(() => addDev(), 405, 406);
runOnKeys(() => deleteDev(), 404, 406);